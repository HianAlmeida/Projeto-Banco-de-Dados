from django.urls import path
from .views import createView, store

urlpatterns = [
    path('create',createView),
    path('store',store,name='store'),
]