from django.shortcuts import render, redirect
from .models import Filme
from django.contrib import messages
# Create your views here.
def createView(request):
    return render(request,'criar_filme.html')



def store(request):
    filme = Filme()
    filme.nome = request.POST.get('filme_nome')
    filme.categoria = request.POST.get('filme_categoria')
    filme.empresa_produtora = request.POST.get('filme_empresa_produtora')
    filme.nacional = True if request.POST.get('filme_nacional') else False
    filme.censura = request.POST.get('filme_censura')
    filme.duracao = request.POST.get('filme_duracao')

    filme.save()
    messages.success(request, "Filme criado com sucesso")
    return redirect('/cinema/create')
